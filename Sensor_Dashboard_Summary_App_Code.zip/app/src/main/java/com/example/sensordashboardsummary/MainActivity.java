package com.example.sensordashboardsummary;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.sensordashboardsummary.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_dashboard, R.id.nav_summary)
                .setOpenableLayout(drawer)
                .build();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        // ✅ Set refresh button to reload the correct WebView
        binding.appBarMain.fab.setOnClickListener(v -> {
            int currentDestinationId = navController.getCurrentDestination().getId();

            if (currentDestinationId == R.id.nav_dashboard) {
                DashboardFragment dashboardFragment = (DashboardFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.nav_host_fragment_content_main)
                        .getChildFragmentManager()
                        .getFragments()
                        .get(0);
                if (dashboardFragment != null) {
                    dashboardFragment.reloadWebView();
                }
            } else if (currentDestinationId == R.id.nav_summary) {
                SummaryFragment summaryFragment = (SummaryFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.nav_host_fragment_content_main)
                        .getChildFragmentManager()
                        .getFragments()
                        .get(0);
                if (summaryFragment != null) {
                    summaryFragment.reloadWebView();
                }
            } else {
                Snackbar.make(v, "No refreshable content on this page.", Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
