package com.example.sensordashboardsummary;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class SummaryFragment extends Fragment {

    private WebView summaryWebView;
    private FloatingActionButton btnRefresh;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_summary, container, false);

        summaryWebView = root.findViewById(R.id.summaryWebView);
        btnRefresh = root.findViewById(R.id.btnRefresh);

        WebSettings webSettings = summaryWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setTextZoom(100); // Normal zoom

        summaryWebView.setInitialScale(1);
        summaryWebView.setWebViewClient(new WebViewClient());
        summaryWebView.loadUrl("https://lookerstudio.google.com/embed/reporting/539c465f-5813-4fad-b333-68e2e341b934/page/p_vmr6hj9etd");

        btnRefresh.setOnClickListener(v -> summaryWebView.reload());

        return root;
    }
    public void reloadWebView() {
        if (summaryWebView != null) {
            summaryWebView.reload();
        }
    }

}



