package com.example.sensordashboardsummary;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class DashboardFragment extends Fragment {

    private WebView dashboardWebView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_summary, container, false);

        dashboardWebView = root.findViewById(R.id.summaryWebView);

        WebSettings webSettings = dashboardWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setTextZoom(100); // Normal zoom

        dashboardWebView.setInitialScale(1); // Try values between 50 and 100


        dashboardWebView.setWebViewClient(new WebViewClient());
        dashboardWebView.loadUrl("https://lookerstudio.google.com/embed/reporting/539c465f-5813-4fad-b333-68e2e341b934/page/p_nljyeqncrd");

        return root;
    }

    public void reloadWebView() {
        if (dashboardWebView != null) {
            dashboardWebView.reload();
        }
    }

}
